<?php
if (dci_get_option("stemma_comune_mobile")) {
?>
<svg width="48" height="48" aria-hidden="true">       
     <image xlink:href="<?php echo dci_get_option("stemma_comune_mobile");?>" width="48" height="48"/>
</svg>
<?php } ?>