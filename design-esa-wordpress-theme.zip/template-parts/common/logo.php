<?php
if (dci_get_option("stemma_comune")) {
?>
<svg width="82" height="82" class="icon" aria-hidden="true">       
     <image xlink:href="<?php echo dci_get_option("stemma_comune");?>" width="82" height="82"/>    
</svg>
<?php } ?>