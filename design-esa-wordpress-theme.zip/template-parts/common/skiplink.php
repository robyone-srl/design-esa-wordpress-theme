<nav class="skiplink" aria-label="Link per saltare ai contenuti">
    <a class="visually-hidden-focusable" aria-label="Vai ai contenuti presenti in pagina" href="#main-container">Vai ai contenuti</a>
    <a class="visually-hidden-focusable" aria-label="Vai al footer" href="#footer">Vai al footer</a>
</nav><!-- /skiplink -->