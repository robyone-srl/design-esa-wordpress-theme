<a class="btn btn-primary btn-icon py-sm-2" href="#" aria-label="<?php _e("Accedi all'area personale", "design_comuni_italia"); ?>" data-bs-toggle="modal" data-bs-target="#access-modal">
    <span class="rounded-icon">
        <svg class="icon icon-primary">
            <use xlink:href="#it-user"></use>
        </svg>
    </span>
    <span class="d-none d-lg-block"><?php _e("Accedi all'area personale", "design_comuni_italia"); ?></span>
</a>