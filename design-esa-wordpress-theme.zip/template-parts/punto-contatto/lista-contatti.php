<?php
global $post,$custom_style;
$custom_style = 1;
?>

<div class="col-12 col-md-6 col-lg-4">
    <?php 
        get_template_part( 'template-parts/punto-contatto/card');
    ?>
</div>
