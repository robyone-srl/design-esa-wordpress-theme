#!/bin/bash

cp ./node_modules/bootstrap-italia/dist/css/bootstrap-italia-comuni.min.css ./assets/css/bootstrap-italia.min.css
cp ./node_modules/bootstrap-italia/dist/js/bootstrap-italia.bundle.min.js ./assets/js/bootstrap-italia.bundle.min.js